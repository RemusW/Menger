#include "menger.h"
#include "iostream"

using namespace std;

namespace {
	const int kMinLevel = 0;
	const int kMaxLevel = 4;
};

Menger::Menger()
{
	// Add additional initialization if you like
}

Menger::~Menger()
{
}

void
Menger::set_nesting_level(int level)
{
	nesting_level_ = level;
	dirty_ = true;
}

bool
Menger::is_dirty() const
{
	return dirty_;
}

void
Menger::set_clean()
{
	dirty_ = false;
}

// FIXME generate Menger sponge geometry
void
Menger::generate_geometry(std::vector<glm::vec4>& obj_vertices,
                          std::vector<glm::uvec3>& obj_faces) const
{
	double M = .5f;
	double m = -1*M;
	// Create starting cube
	obj_vertices.push_back(glm::vec4(m,m,m, 1));	// far-bot left
	obj_vertices.push_back(glm::vec4(M,m,m, 1));	// far-bot right
	obj_vertices.push_back(glm::vec4(M,m,M, 1));	// near-bot right
	obj_vertices.push_back(glm::vec4(m,m,M, 1));	// near_bot left
	obj_vertices.push_back(glm::vec4(m,M,m, 1));	// far-top left
	obj_vertices.push_back(glm::vec4(M,M,m, 1));	// far-top right
	obj_vertices.push_back(glm::vec4(M,M,M, 1));	// near-top right
	obj_vertices.push_back(glm::vec4(m,M,M, 1));	// near_top left

	obj_faces.push_back(glm::uvec3(0, 1, 2));
	obj_faces.push_back(glm::uvec3(0, 4, 3));
	obj_faces.push_back(glm::uvec3(0, 3, 6));

	for(int i=0; i<nesting_level_; i++) {

	}

	// cout << "test\n";
    // cout << "nestlvl%x\n",nesting_level_;
	//draw cube here
	//CreateMenger()
	cout << "amount of faces%x\n",obj_faces.size();
	cout << "amount of object points%x\n",obj_vertices.size();
}

void
Menger::CreateMenger()
{
}